# ensure that PyTorch is correctly installed
import torch
x = torch.rand(5, 3)
print(x)
